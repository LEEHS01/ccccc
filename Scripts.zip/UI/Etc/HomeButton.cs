using System.Collections;
using System.Collections.Generic;
using Onthesys;
using UnityEngine;

internal class HomeButton : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    internal void OnButtonClick() {
    }
}
