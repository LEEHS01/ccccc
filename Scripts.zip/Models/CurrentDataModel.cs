﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Onthesys.ExeBuild
{
    [System.Serializable]
    internal class CurrentDataModel
    {
        internal int hnsidx;
        internal int boardidx;
        internal string stcd;
        internal float? val;
        internal float hihi;
        internal float hi;
        internal string useyn;
        internal string fix;
    }
}
