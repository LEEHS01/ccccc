﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Onthesys.ExeBuild
{
    [System.Serializable]
    internal class AlarmSummaryModel
    {
        internal int obsidx;
        internal int month;
        internal int year;
        internal int cnt;
    }
}
