﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Onthesys.ExeBuild
{
    [System.Serializable]
    internal class AlarmMontlyModel
    {
        internal string areanm;
        internal int cnt;
    }
}
