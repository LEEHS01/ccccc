﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Onthesys.ExeBuild
{
    [System.Serializable]
    internal class AlarmYearlyModel
    {
        internal string areanm;
        internal int ala0;
        internal int ala1;
        internal int ala2;
    }
}
